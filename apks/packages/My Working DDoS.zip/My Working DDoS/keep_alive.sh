#!/bin/bash

while true; do
    curl https://reimagined-parakeet-pjp974v9qjvr37pr.github.dev/
    sleep 60  # Wait for 60 seconds before pinging again (Paste Codespace URL)
done
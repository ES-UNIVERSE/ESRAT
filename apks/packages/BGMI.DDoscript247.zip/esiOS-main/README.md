
# ⚠️ TO RUN YOUR CODESPACE ⚠️

```bash
./keep_alive.sh & python3 sahil.py
```

# Telegram Bot Project 🚀

Welcome to the **Telegram Bot Project**, a custom bot built with Python using the `pyTelegramBotAPI`. This bot automates specific tasks and commands, designed to execute DDoS attacks (for educational purposes), with user management features. It runs continuously in a **GitHub Codespace** using a keep-alive script.

---

## 📁 Project Structure

- **`sahil.py`**: The main Python script that runs the bot and handles commands.
- **`bgmi`**: The executable responsible for attack logic.
- **`config.json`**: Stores your bot token and admin IDs.
- **`keep_alive.sh`**: Bash script to keep your Codespace alive with periodic pings. (I use this to keep bot alive for 24/7)
- **`install.sh`**: Sets up the environment within the Codespace.
- **`.github/workflows/keep_alive.yml`**: GitHub Actions workflow to ping the Codespace every 5 minutes. But I'm not using this, using keep_alive.sh file for keeping bot alive for 24/7.

---

## 🛠️ Prerequisites

Ensure you have the following:

- **Python 3.8+**
- **MongoDB** (Note: MongoDB isn't used here)
- **GitHub Codespace** or any other cloud-based environment
- **`pyTelegramBotAPI`** library installed

---

## 📥 Setup and Installation

### Step 1: Clone the repository

```bash
git clone https://github.com/yourusername/your-repository.git
cd your-repository
```

### Step 2: Install the dependencies

Run the `install.sh` file to set up your environment:

```bash
./install.sh
```

### Step 3: Configure the bot

Update `config.json` with your **bot token** and **admin IDs**:

```json
{
  "bot_token": "YOUR_BOT_TOKEN",
  "admin_ids": [YOUR_ADMIN_ID]
}
```

---

## 🚀 Running the Bot

To start the bot, simply run:

```bash
python3 sahil.py
```

To keep the bot running in the background:

```bash
./keep_alive.sh & python3 sahil.py
```

---

## 💡 Tips and Troubleshooting

- **Permission Denied (bgmi)**: If you encounter a permission error for the `bgmi` executable, use:

  ```bash
  chmod +x bgmi
  ```

- **Bot Not Responding**: Ensure the bot token is correct in `config.json`. Also, verify that you are using long polling instead of webhooks.

---

## ⏱️ Keeping the Bot Alive in GitHub Actions

GitHub Actions ensures your Codespace stays active. The `keep_alive.yml` workflow triggers a ping every 5 minutes.

### Manual Trigger

Push any changes to trigger the workflow or re-run it from the GitHub Actions dashboard.

```yaml
on:
  schedule:
    - cron: '*/5 * * * *'  # Runs every 5 minutes
```

---

## 🎯 Future Enhancements

- Add more commands to extend bot functionality.
- Deploy via webhook for faster response times.
- Improve logging and error handling for production use.

---

## 🔏 License

This project is licensed under the MIT License. Feel free to contribute and improve upon it!
